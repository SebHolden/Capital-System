# Seb Capital System

Private Next.js dashboard for portfolio discipline, risk control, simulated orders and broker-ready execution architecture.

## What this project does

- Tracks a sample 10,000 EUR portfolio.
- Calculates allocation, concentration and simple crash scenarios.
- Simulates a proposed buy order before any real execution.
- Provides an execution layer with three modes:
  - `mock`: default, no external broker, no real money.
  - `paper`: intended for paper trading APIs.
  - `live`: blocked unless `ENABLE_LIVE_TRADING=true`.

## What this project intentionally does not do yet

- It does not place real-money orders by default.
- It does not use leverage.
- It does not withdraw funds.
- It does not make financial recommendations.

## Setup

```bash
npm install
cp .env.example .env.local
npm run dev
```

Open http://localhost:3000

## Safety model

Live trading is disabled unless both conditions are true:

```env
EXECUTION_MODE=live
ENABLE_LIVE_TRADING=true
```

Even then, the order route requires explicit acknowledgement and passes through the risk gate.

## Suggested next implementation steps

1. Add persistent storage with SQLite or Postgres.
2. Add journal entries before every simulated order.
3. Add paper trading with Alpaca.
4. Add crypto execution only after API keys are restricted to trading-only permissions.
5. Add a manual kill switch in the UI.
