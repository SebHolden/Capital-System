"use client";

import { useMemo, useState } from "react";
import { SAMPLE_POSITIONS, DEFAULT_RISK_RULES } from "@/lib/config";
import { evaluateOrder, formatEur, formatPct, summarizePortfolio } from "@/lib/risk";
import type { AssetKind, ProposedOrder, RiskDecision } from "@/lib/types";

const assetKindLabels: Record<AssetKind, string> = {
  cash: "Liquidità",
  etf: "ETF",
  stock: "Azioni",
  crypto: "Crypto",
  experimental: "Esperimenti",
};

function Badge({ verdict }: { verdict: RiskDecision["verdict"] }) {
  const label = verdict === "green" ? "VERDE" : verdict === "yellow" ? "GIALLO" : verdict === "red" ? "ROSSO" : "NERO";
  return <span className={`badge ${verdict === "green" ? "green" : verdict === "yellow" ? "yellow" : "red"}`}>{label}</span>;
}

export default function Home() {
  const portfolio = useMemo(() => summarizePortfolio(SAMPLE_POSITIONS), []);
  const [symbol, setSymbol] = useState("BTC");
  const [kind, setKind] = useState<Exclude<AssetKind, "cash">>("crypto");
  const [amountEur, setAmountEur] = useState(250);
  const [currentPrice, setCurrentPrice] = useState(70000);
  const [journalText, setJournalText] = useState("Operazione di esempio: voglio testare il sistema senza usare soldi veri.");
  const [apiResult, setApiResult] = useState<unknown>(null);
  const [loading, setLoading] = useState(false);

  const proposedOrder: ProposedOrder = {
    symbol,
    kind,
    side: "buy",
    amountEur,
    currentPrice,
    journalText,
  };

  const decision = evaluateOrder(SAMPLE_POSITIONS, proposedOrder, DEFAULT_RISK_RULES);

  async function simulateOnServer() {
    setLoading(true);
    setApiResult(null);
    try {
      const response = await fetch("/api/execution/simulate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(proposedOrder),
      });
      setApiResult(await response.json());
    } finally {
      setLoading(false);
    }
  }

  async function mockExecute() {
    setLoading(true);
    setApiResult(null);
    try {
      const response = await fetch("/api/execution/order", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...proposedOrder, acknowledgeRisk: true }),
      });
      setApiResult(await response.json());
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="container">
      <section className="hero">
        <div>
          <div className="eyebrow">Private investing OS</div>
          <h1>Seb Capital System</h1>
          <p>
            Dashboard personale per rischio, disciplina, simulazione operazioni e architettura pronta per broker API.
            Di default non invia ordini reali.
          </p>
        </div>
        <div className="badge">EXECUTION_MODE: mock</div>
      </section>

      <section className="grid">
        <div className="card">
          <h2>Patrimonio</h2>
          <div className="metric">{formatEur(portfolio.totalValue)}</div>
          <p className="muted">Scenario ipotetico iniziale da 10.000 €.</p>
        </div>

        <div className="card">
          <h2>Liquidità</h2>
          <div className="metric">{formatPct(portfolio.cashValue / portfolio.totalValue)}</div>
          <p className="muted">Riserva minima: {formatEur(DEFAULT_RISK_RULES.minCashReserveEur)}.</p>
        </div>

        <div className="card">
          <h2>Stress test</h2>
          <div className="metric">{formatEur(portfolio.simpleCrashScenario.combinedStress)}</div>
          <p className="muted">Crypto -50% e ETF/Azioni -20%, modello semplificato.</p>
        </div>

        <div className="card wide">
          <h2>Allocazione</h2>
          {portfolio.allocations.map((row) => (
            <div className="row" key={row.kind}>
              <span>{assetKindLabels[row.kind]}</span>
              <strong>{formatEur(row.value)} · {formatPct(row.allocation)}</strong>
            </div>
          ))}
        </div>

        <div className="card">
          <h2>Regole attive</h2>
          <ul>
            <li>Crypto max: {formatPct(DEFAULT_RISK_RULES.maxCryptoAllocation)}</li>
            <li>Esperimenti max: {formatPct(DEFAULT_RISK_RULES.maxExperimentalAllocation)}</li>
            <li>Singolo asset max: {formatPct(DEFAULT_RISK_RULES.maxSingleAssetAllocation)}</li>
            <li>Leva: vietata</li>
            <li>Diario: obbligatorio</li>
          </ul>
        </div>

        <div className="card full">
          <h2>Simula ordine</h2>
          <div className="inputGrid">
            <label>
              Simbolo
              <input value={symbol} onChange={(e) => setSymbol(e.target.value.toUpperCase())} />
            </label>
            <label>
              Tipo asset
              <select value={kind} onChange={(e) => setKind(e.target.value as Exclude<AssetKind, "cash">)}>
                <option value="etf">ETF</option>
                <option value="stock">Azione</option>
                <option value="crypto">Crypto</option>
                <option value="experimental">Esperimento</option>
              </select>
            </label>
            <label>
              Importo EUR
              <input type="number" value={amountEur} onChange={(e) => setAmountEur(Number(e.target.value))} />
            </label>
            <label>
              Prezzo attuale
              <input type="number" value={currentPrice} onChange={(e) => setCurrentPrice(Number(e.target.value))} />
            </label>
          </div>
          <label style={{ marginTop: 12 }}>
            Diario decisionale
            <input value={journalText} onChange={(e) => setJournalText(e.target.value)} />
          </label>

          <div style={{ marginTop: 16, display: "flex", gap: 12, flexWrap: "wrap" }}>
            <button onClick={simulateOnServer} disabled={loading}>{loading ? "Carico..." : "Simula lato server"}</button>
            <button className="secondary" onClick={mockExecute} disabled={loading}>Esegui in mock mode</button>
          </div>
        </div>

        <div className="card wide">
          <h2>Verdetto locale</h2>
          <Badge verdict={decision.verdict} />
          <div className="metric" style={{ fontSize: 24 }}>{decision.title}</div>
          <ul>
            {decision.reasons.map((reason) => <li key={reason}>{reason}</li>)}
            {decision.warnings.map((warning) => <li key={warning}>{warning}</li>)}
          </ul>
        </div>

        <div className="card">
          <h2>Broker API</h2>
          <p>
            Il modulo esecuzione è già predisposto, ma parte in mock mode. La modalità paper/live passa sempre dal risk gate.
          </p>
        </div>

        {apiResult ? (
          <div className="card full">
            <h2>Risposta API</h2>
            <pre>{JSON.stringify(apiResult, null, 2)}</pre>
          </div>
        ) : null}
      </section>
    </main>
  );
}
