import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Seb Capital System",
  description: "Private portfolio risk and execution dashboard",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="it">
      <body>{children}</body>
    </html>
  );
}
