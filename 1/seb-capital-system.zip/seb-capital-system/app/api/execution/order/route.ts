import { NextResponse } from "next/server";
import { DEFAULT_RISK_RULES, SAMPLE_POSITIONS } from "@/lib/config";
import { getBroker, getExecutionMode } from "@/lib/brokers";
import { evaluateOrder } from "@/lib/risk";
import type { ProposedOrder } from "@/lib/types";

export async function POST(request: Request) {
  const order = (await request.json()) as ProposedOrder;
  const mode = getExecutionMode();
  const decision = evaluateOrder(SAMPLE_POSITIONS, order, DEFAULT_RISK_RULES);

  if (decision.verdict === "black" || decision.verdict === "red") {
    return NextResponse.json({ executed: false, mode, decision, result: null }, { status: 400 });
  }

  if (!order.acknowledgeRisk) {
    return NextResponse.json(
      {
        executed: false,
        mode,
        decision,
        result: null,
        error: "Risk acknowledgement required before execution.",
      },
      { status: 400 },
    );
  }

  if (mode === "live" && process.env.ENABLE_LIVE_TRADING !== "true") {
    return NextResponse.json(
      {
        executed: false,
        mode: "mock",
        decision,
        result: null,
        error: "Live trading is disabled. Set ENABLE_LIVE_TRADING=true only after paper testing.",
      },
      { status: 403 },
    );
  }

  const broker = getBroker();
  const result = await broker.placeOrder(order);
  return NextResponse.json({ executed: result.accepted, mode: broker.mode, decision, result });
}
