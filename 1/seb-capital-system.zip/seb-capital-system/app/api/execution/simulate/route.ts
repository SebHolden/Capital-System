import { NextResponse } from "next/server";
import { DEFAULT_RISK_RULES, SAMPLE_POSITIONS } from "@/lib/config";
import { evaluateOrder, simulateBuy, summarizePortfolio } from "@/lib/risk";
import type { ProposedOrder } from "@/lib/types";

export async function POST(request: Request) {
  const order = (await request.json()) as ProposedOrder;
  const decision = evaluateOrder(SAMPLE_POSITIONS, order, DEFAULT_RISK_RULES);
  const after = order.side === "buy" ? summarizePortfolio(simulateBuy(SAMPLE_POSITIONS, order)) : summarizePortfolio(SAMPLE_POSITIONS);

  return NextResponse.json({ decision, after });
}
