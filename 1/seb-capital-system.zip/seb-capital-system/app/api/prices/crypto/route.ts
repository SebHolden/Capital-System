import { NextResponse } from "next/server";

const ids: Record<string, string> = {
  BTC: "bitcoin",
  ETH: "ethereum",
  SOL: "solana",
};

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const symbols = (searchParams.get("symbols") ?? "BTC,ETH")
    .split(",")
    .map((s) => s.trim().toUpperCase())
    .filter(Boolean);

  const coinIds = symbols.map((s) => ids[s]).filter(Boolean).join(",");
  if (!coinIds) return NextResponse.json({ prices: {} });

  const url = `https://api.coingecko.com/api/v3/simple/price?ids=${coinIds}&vs_currencies=eur&include_24hr_change=true`;
  const response = await fetch(url, { next: { revalidate: 60 } });

  if (!response.ok) {
    return NextResponse.json({ error: "CoinGecko request failed" }, { status: 502 });
  }

  const data = await response.json();
  const prices = Object.entries(ids).reduce<Record<string, unknown>>((acc, [symbol, id]) => {
    if (data[id]) acc[symbol] = data[id];
    return acc;
  }, {});

  return NextResponse.json({ prices });
}
