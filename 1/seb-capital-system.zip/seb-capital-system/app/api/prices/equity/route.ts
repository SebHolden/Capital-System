import { NextResponse } from "next/server";

export async function GET(request: Request) {
  const apiKey = process.env.FINNHUB_API_KEY;
  if (!apiKey) {
    return NextResponse.json({ error: "Missing FINNHUB_API_KEY" }, { status: 500 });
  }

  const { searchParams } = new URL(request.url);
  const symbol = searchParams.get("symbol") ?? "VWCE.DE";
  const url = `https://finnhub.io/api/v1/quote?symbol=${encodeURIComponent(symbol)}&token=${apiKey}`;

  const response = await fetch(url, { next: { revalidate: 60 } });
  if (!response.ok) {
    return NextResponse.json({ error: "Finnhub request failed" }, { status: 502 });
  }

  const data = await response.json();
  return NextResponse.json({ symbol, quote: data });
}
