export type AssetKind = "cash" | "etf" | "stock" | "crypto" | "experimental";

export type Position = {
  id: string;
  symbol: string;
  name: string;
  kind: AssetKind;
  currency: "EUR" | "USD";
  quantity: number;
  currentPrice: number;
  averagePrice?: number;
};

export type RiskRules = {
  maxCryptoAllocation: number;
  maxExperimentalAllocation: number;
  maxSingleAssetAllocation: number;
  maxSingleCryptoAllocation: number;
  minCashReserveEur: number;
  maxMonthlyLoss: number;
  leverageAllowed: boolean;
  requireJournalBeforeTrade: boolean;
  blockTradesAfterHour: string;
  blockIfAssetUp7dMoreThan: number;
};

export type AllocationRow = {
  kind: AssetKind;
  value: number;
  allocation: number;
};

export type PortfolioSummary = {
  totalValue: number;
  cashValue: number;
  investedValue: number;
  allocations: AllocationRow[];
  topPosition: { symbol: string; allocation: number } | null;
  simpleCrashScenario: {
    cryptoMinus50: number;
    equitiesMinus20: number;
    combinedStress: number;
  };
};

export type ProposedOrder = {
  assetId?: string;
  symbol: string;
  name?: string;
  kind: Exclude<AssetKind, "cash">;
  side: "buy" | "sell";
  amountEur: number;
  currentPrice: number;
  journalText?: string;
  acknowledgeRisk?: boolean;
};

export type RiskDecision = {
  verdict: "green" | "yellow" | "red" | "black";
  title: string;
  allowedAmountEur: number;
  reasons: string[];
  warnings: string[];
};

export type ExecutionMode = "mock" | "paper" | "live";

export type BrokerOrderResult = {
  broker: string;
  mode: ExecutionMode;
  accepted: boolean;
  externalOrderId?: string;
  message: string;
  raw?: unknown;
};
