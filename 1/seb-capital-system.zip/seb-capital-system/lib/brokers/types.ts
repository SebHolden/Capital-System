import type { BrokerOrderResult, ExecutionMode, ProposedOrder } from "../types";

export interface BrokerAdapter {
  readonly name: string;
  readonly mode: ExecutionMode;
  placeOrder(order: ProposedOrder): Promise<BrokerOrderResult>;
}
