import type { BrokerAdapter } from "./types";
import type { ExecutionMode } from "../types";
import { MockBroker } from "./mockBroker";
import { AlpacaBroker } from "./alpacaBroker";

export function getExecutionMode(): ExecutionMode {
  const mode = process.env.EXECUTION_MODE;
  if (mode === "paper" || mode === "live") return mode;
  return "mock";
}

export function getBroker(): BrokerAdapter {
  const mode = getExecutionMode();

  if (mode === "live" && process.env.ENABLE_LIVE_TRADING !== "true") {
    return new MockBroker("mock");
  }

  if (mode === "paper" || mode === "live") {
    return new AlpacaBroker(mode);
  }

  return new MockBroker("mock");
}
