import type { BrokerOrderResult, ExecutionMode, ProposedOrder } from "../types";
import type { BrokerAdapter } from "./types";

export class MockBroker implements BrokerAdapter {
  readonly name = "MockBroker";
  readonly mode: ExecutionMode;

  constructor(mode: ExecutionMode = "mock") {
    this.mode = mode;
  }

  async placeOrder(order: ProposedOrder): Promise<BrokerOrderResult> {
    return {
      broker: this.name,
      mode: this.mode,
      accepted: true,
      externalOrderId: `mock_${Date.now()}`,
      message: `Ordine simulato: ${order.side.toUpperCase()} ${order.symbol} per ${order.amountEur} EUR. Nessun ordine reale inviato.`,
    };
  }
}
