import type { BrokerOrderResult, ExecutionMode, ProposedOrder } from "../types";
import type { BrokerAdapter } from "./types";

export class CoinbaseBroker implements BrokerAdapter {
  readonly name = "CoinbaseAdvanced";
  readonly mode: ExecutionMode;

  constructor(mode: ExecutionMode) {
    this.mode = mode;
  }

  async placeOrder(_order: ProposedOrder): Promise<BrokerOrderResult> {
    // Stub by design.
    // Coinbase Advanced uses signed private REST requests and scoped API keys.
    // Implement only after trading-only permissions, small size limits and full logging are added.
    return {
      broker: this.name,
      mode: this.mode,
      accepted: false,
      message: "Coinbase execution adapter not enabled yet. Use mock/paper first.",
    };
  }
}
