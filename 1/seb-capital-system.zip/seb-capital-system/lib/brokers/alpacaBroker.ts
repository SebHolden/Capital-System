import type { BrokerOrderResult, ExecutionMode, ProposedOrder } from "../types";
import type { BrokerAdapter } from "./types";

function env(name: string): string {
  const value = process.env[name];
  if (!value) throw new Error(`Missing environment variable: ${name}`);
  return value;
}

export class AlpacaBroker implements BrokerAdapter {
  readonly name = "Alpaca";
  readonly mode: ExecutionMode;
  private readonly baseUrl: string;
  private readonly key: string;
  private readonly secret: string;

  constructor(mode: ExecutionMode) {
    if (mode !== "paper" && mode !== "live") {
      throw new Error("AlpacaBroker can only be used in paper or live mode.");
    }
    this.mode = mode;
    this.baseUrl = mode === "paper" ? env("ALPACA_PAPER_BASE_URL") : env("ALPACA_LIVE_BASE_URL");
    this.key = env("ALPACA_API_KEY");
    this.secret = env("ALPACA_API_SECRET");
  }

  async placeOrder(order: ProposedOrder): Promise<BrokerOrderResult> {
    // Minimal example for stocks/ETFs. Crypto/product support depends on account region and enabled products.
    // In production, map EUR amount to notional supported by the broker/instrument currency.
    const payload = {
      symbol: order.symbol,
      notional: String(order.amountEur),
      side: order.side,
      type: "market",
      time_in_force: "day",
    };

    const response = await fetch(`${this.baseUrl}/v2/orders`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "APCA-API-KEY-ID": this.key,
        "APCA-API-SECRET-KEY": this.secret,
      },
      body: JSON.stringify(payload),
    });

    const data = await response.json().catch(() => ({}));

    return {
      broker: this.name,
      mode: this.mode,
      accepted: response.ok,
      externalOrderId: typeof data?.id === "string" ? data.id : undefined,
      message: response.ok ? "Ordine inviato ad Alpaca." : `Ordine rifiutato da Alpaca: ${response.status}`,
      raw: data,
    };
  }
}
