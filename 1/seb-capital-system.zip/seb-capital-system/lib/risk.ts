import type { AllocationRow, AssetKind, PortfolioSummary, Position, ProposedOrder, RiskDecision, RiskRules } from "./types";

export function positionValue(position: Position): number {
  return position.quantity * position.currentPrice;
}

export function summarizePortfolio(positions: Position[]): PortfolioSummary {
  const totalValue = positions.reduce((sum, p) => sum + positionValue(p), 0);
  const cashValue = positions.filter((p) => p.kind === "cash").reduce((sum, p) => sum + positionValue(p), 0);
  const byKind = new Map<AssetKind, number>();

  for (const position of positions) {
    byKind.set(position.kind, (byKind.get(position.kind) ?? 0) + positionValue(position));
  }

  const allocations: AllocationRow[] = Array.from(byKind.entries()).map(([kind, value]) => ({
    kind,
    value,
    allocation: totalValue > 0 ? value / totalValue : 0,
  }));

  const top = positions
    .filter((p) => p.kind !== "cash")
    .map((p) => ({ symbol: p.symbol, allocation: totalValue > 0 ? positionValue(p) / totalValue : 0 }))
    .sort((a, b) => b.allocation - a.allocation)[0] ?? null;

  const cryptoValue = positions.filter((p) => p.kind === "crypto").reduce((sum, p) => sum + positionValue(p), 0);
  const equitiesValue = positions.filter((p) => p.kind === "etf" || p.kind === "stock").reduce((sum, p) => sum + positionValue(p), 0);

  return {
    totalValue,
    cashValue,
    investedValue: totalValue - cashValue,
    allocations,
    topPosition: top,
    simpleCrashScenario: {
      cryptoMinus50: cryptoValue * -0.5,
      equitiesMinus20: equitiesValue * -0.2,
      combinedStress: cryptoValue * -0.5 + equitiesValue * -0.2,
    },
  };
}

export function simulateBuy(positions: Position[], order: ProposedOrder): Position[] {
  if (order.side !== "buy") return positions;

  const quantityToAdd = order.amountEur / order.currentPrice;
  const existing = positions.find((p) => p.symbol.toUpperCase() === order.symbol.toUpperCase());
  const cash = positions.find((p) => p.kind === "cash");

  const updated = positions.map((p) => {
    if (p.id === cash?.id) {
      return { ...p, quantity: Math.max(0, p.quantity - order.amountEur) };
    }
    if (existing && p.id === existing.id) {
      return { ...p, quantity: p.quantity + quantityToAdd, currentPrice: order.currentPrice };
    }
    return p;
  });

  if (!existing) {
    updated.push({
      id: `${order.symbol.toLowerCase()}-${Date.now()}`,
      symbol: order.symbol.toUpperCase(),
      name: order.name ?? order.symbol.toUpperCase(),
      kind: order.kind,
      currency: "EUR",
      quantity: quantityToAdd,
      currentPrice: order.currentPrice,
      averagePrice: order.currentPrice,
    });
  }

  return updated;
}

export function evaluateOrder(positions: Position[], order: ProposedOrder, rules: RiskRules): RiskDecision {
  const before = summarizePortfolio(positions);
  const afterPositions = order.side === "buy" ? simulateBuy(positions, order) : positions;
  const after = summarizePortfolio(afterPositions);

  const reasons: string[] = [];
  const warnings: string[] = [];
  let verdict: RiskDecision["verdict"] = "green";
  let allowedAmount = order.amountEur;

  if (order.amountEur <= 0) {
    return {
      verdict: "black",
      title: "Operazione non valida",
      allowedAmountEur: 0,
      reasons: ["L'importo deve essere maggiore di zero."],
      warnings: [],
    };
  }

  if (!rules.leverageAllowed && order.amountEur > before.cashValue && order.side === "buy") {
    verdict = "black";
    allowedAmount = Math.max(0, before.cashValue - rules.minCashReserveEur);
    reasons.push("L'operazione richiederebbe leva o più liquidità di quella disponibile.");
  }

  if (order.side === "buy" && after.cashValue < rules.minCashReserveEur) {
    verdict = verdict === "black" ? "black" : "red";
    allowedAmount = Math.min(allowedAmount, Math.max(0, before.cashValue - rules.minCashReserveEur));
    reasons.push(`Dopo l'acquisto la liquidità scenderebbe sotto la riserva minima di ${formatEur(rules.minCashReserveEur)}.`);
  }

  const cryptoAllocation = after.allocations.find((a) => a.kind === "crypto")?.allocation ?? 0;
  if (cryptoAllocation > rules.maxCryptoAllocation) {
    verdict = verdict === "black" ? "black" : "red";
    reasons.push(`La quota crypto salirebbe al ${formatPct(cryptoAllocation)}, oltre il limite del ${formatPct(rules.maxCryptoAllocation)}.`);
  }

  const experimentalAllocation = after.allocations.find((a) => a.kind === "experimental")?.allocation ?? 0;
  if (experimentalAllocation > rules.maxExperimentalAllocation) {
    verdict = verdict === "black" ? "black" : "red";
    reasons.push(`La quota sperimentale salirebbe al ${formatPct(experimentalAllocation)}, oltre il limite del ${formatPct(rules.maxExperimentalAllocation)}.`);
  }

  const newPosition = afterPositions.find((p) => p.symbol.toUpperCase() === order.symbol.toUpperCase());
  const newAllocation = newPosition ? positionValue(newPosition) / after.totalValue : 0;
  if (newAllocation > rules.maxSingleAssetAllocation) {
    verdict = verdict === "black" ? "black" : "red";
    reasons.push(`La posizione ${order.symbol.toUpperCase()} arriverebbe al ${formatPct(newAllocation)}, oltre il limite singolo del ${formatPct(rules.maxSingleAssetAllocation)}.`);
  }

  if (order.kind === "crypto" && newAllocation > rules.maxSingleCryptoAllocation) {
    verdict = verdict === "black" ? "black" : "red";
    reasons.push(`La singola crypto arriverebbe al ${formatPct(newAllocation)}, oltre il limite del ${formatPct(rules.maxSingleCryptoAllocation)}.`);
  }

  if (rules.requireJournalBeforeTrade && (!order.journalText || order.journalText.trim().length < 25)) {
    verdict = verdict === "green" ? "yellow" : verdict;
    warnings.push("Diario troppo breve: scrivi perché questa operazione è razionale, non emotiva.");
  }

  if (verdict === "green") {
    reasons.push("Operazione coerente con le regole base del portafoglio.");
  }

  const titleMap: Record<RiskDecision["verdict"], string> = {
    green: "Operazione approvata",
    yellow: "Operazione consentita con cautela",
    red: "Operazione sconsigliata",
    black: "Operazione bloccata",
  };

  return {
    verdict,
    title: titleMap[verdict],
    allowedAmountEur: Math.max(0, allowedAmount),
    reasons,
    warnings,
  };
}

export function formatEur(value: number): string {
  return new Intl.NumberFormat("it-IT", { style: "currency", currency: "EUR", maximumFractionDigits: 0 }).format(value);
}

export function formatPct(value: number): string {
  return new Intl.NumberFormat("it-IT", { style: "percent", maximumFractionDigits: 1 }).format(value);
}
